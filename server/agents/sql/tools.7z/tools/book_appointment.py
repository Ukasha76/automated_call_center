from agents.sql.tools.functions.book_appointment.create_appointment_record import create_appointment_record
from agents.sql.tools.functions.book_appointment.extract_patient_details import extract_patient_details
from agents.sql.tools.functions.appointmentSlots_info.get_available_slots import get_available_slots    
from agents.sql.tools.functions.doctor_details.get_doctor_name import get_doctor_name
from langchain.tools import StructuredTool
from agents.sql.tools.functions.register_patient.extract_patient_info import extract_patient_info
from agents.sql.tools.register_patient import run_register_patient
from agents.sql.tools.functions.find_best_match import find_best_match
from pydantic import BaseModel, Field
from typing import Dict, Any
from typing import Union 
import logging
import asyncio
import json
from agents.sql.tools.functions._build_response import _build_response

import time

logger = logging.getLogger(__name__)

class AppointmentBookingTool:
    def __init__(self):
        self.current_step = "get_doctor"
        self.collected_data = {}

    async def invoke(self, input_data: Any, context: Dict = None) -> Dict:
        """Main entry point with complete type safety"""
        try:
            # Debug what we received
            logger.debug(f"Raw input: {input_data} (type: {type(input_data)})")

            # Convert to safe format
            safe_input = self._normalize_input(input_data)
            
            # Extract values with guarantees
            query = str(safe_input['query_text'])
            ctx = safe_input.get('context', {}) or (context if isinstance(context, dict) else {})
            
            logger.debug(f"Processing - query: '{query}', context keys: {list(ctx.keys())}")
            return await self.handle_query(query, ctx)
            
        except Exception as e:
            logger.error(f"Booking error: {str(e)}", exc_info=True)
            return {
                "output": "We encountered a booking system error. Please try again.",
                "status": "error",
                "current_step": "get_doctor"
            }

    def _normalize_input(self, input_data: Any) -> Dict[str, Any]:
        """More robust input normalization"""
        normalized = {"query_text": "", "context": {}}
        
        if isinstance(input_data, dict):
            normalized["query_text"] = str(input_data.get("query_text", input_data.get("input", "")))
            if "context" in input_data:
                normalized["context"] = input_data["context"] if isinstance(input_data["context"], dict) else {}
        elif isinstance(input_data, str):
            try:
                parsed = json.loads(input_data)
                if isinstance(parsed, dict):
                    return self._normalize_input(parsed)
                normalized["query_text"] = str(parsed)
            except json.JSONDecodeError:
                normalized["query_text"] = input_data
        else:
            normalized["query_text"] = str(input_data)
            
        return normalized

    # async def _get_doctor_step(self, input_str: str) -> Dict:
    #     """Handle doctor selection step"""
    #     if not input_str.strip():
    #         return {
    #             "output": "Which doctor would you like to see? Please provide their full name.",
    #             "current_step": "get_doctor",
    #             "collected_data": {},  
    #             "current_tool":"booking_appointment",
    #             "status": "in_progress"
    #         }
        
    #     name_result = await extract_patient_info(input_str, 'doctor_name')

    #     response = await find_best_match(name_result["value"])

    #     if not response.get("name"):
    #         return {
    #             "output": f"Couldn't find doctor, Which doctor you wanna book an appointment ? ",
    #             "current_step": "get_doctor",
    #             "collected_data": {},
    #             "current_tool":"booking_appointment",

    #             "status": "in_progress"
    #         }       
    #     doctor_name = response["name"]
    #     doctor_id = response["doctor_id"]
        
    #     slots_result = await get_available_slots(doctor_id)
        
    #     if not slots_result.get("success"):
    #         return {
    #             "output": f"Dr. {doctor_name} has no available slots currently.",
    #             "current_step": "get_doctor",
    #             "collected_data": {},
    #             "status": "resolved"
    #         }
        
    #     # Format slots for better readability
    #     slots_formatted = "\n".join(
    #         f"- {slot[0]} at {slot[1]}" 
    #         for slot in slots_result["value"]
    #     )
    #     self.collected_data["doctor"] = doctor_name
    #     self.collected_data["doctor_id"] = doctor_id
    #     self.collected_data["available_slots"] = slots_formatted
    #     return {
    #         "output": f"Dr. {doctor_name} has these available slots:\n{slots_formatted}\n\nWhich slot would you like?",
    #         "current_step": "get_time",
    #         "collected_data": self.collected_data,
    #         "current_tool":"booking_appointment",
    #         "status": "in_progress"
    #     }
    async def _get_doctor_step(self, input_str: str) -> Dict:
        """Handle doctor selection step with validation and error handling.
        
        Args:
            input_str: The user-provided doctor name
            
        Returns:
            Dictionary with:
            - response: Message to display to user
            - current_step: Next step in workflow
            - collected_data: Updated context data
            - status: Current status of workflow
        """
        step_start_time = time.time()
        subactions = []

        try:
            # Clean and validate input
            input_str = str(input_str).strip() if input_str else ""
            
            if not input_str:
                return _build_response(
                    "Which doctor would you like to see? Please provide their full name.",
                    'get_doctor',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Extract doctor name
            llm_start = time.time()
            name_result = await extract_patient_info(input_str, 'doctor_name')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_doctor_name",
                "reason": name_result["value"],
                "success": name_result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not name_result['success']:
                return _build_response(
                    name_result['value'],
                    'get_doctor',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Find doctor match
            db_start = time.time()
            response = await find_best_match(name_result["value"])
            db_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "find_doctor_match",
                "success": bool(response.get("name")),
                "reason": response.get("message", "Doctor lookup"),
                "duration_ms": round((db_end - db_start) * 1000, 2)
            })

            if not response.get("name"):
                return _build_response(
                    f"Couldn't find doctor. Which doctor would you like to book an appointment with?",
                    'get_doctor',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            doctor_name = response["name"]
            doctor_id = response["doctor_id"]
            
            # Get available slots
            slots_start = time.time()
            slots_result = await get_available_slots(doctor_id)
            slots_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "get_available_slots",
                "success": slots_result.get("success", False),
                "reason": slots_result.get("message", "Slot availability check"),
                "duration_ms": round((slots_end - slots_start) * 1000, 2)
            })

            if not slots_result.get("success"):
                return _build_response(
                    f"Dr. {doctor_name} has no available slots currently.",
                    'get_doctor',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            # Format slots for better readability
            slots_formatted = "\n".join(
                f"- {slot[0]} at {slot[1]}" 
                for slot in slots_result["value"]
            )
            
            # Update collected data
            self.collected_data.update({
                "doctor": doctor_name,
                "doctor_id": doctor_id,
                "available_slots": slots_formatted
            })

            return _build_response(
                f"Dr. {doctor_name} has these available slots:\n{slots_formatted}\n\nWhich slot would you like?",
                'get_time',
                self.collected_data,
                # 'in_progress',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in doctor selection step: {str(e)}", exc_info=True)
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_doctor_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing the doctor selection. Please try again.",
                'get_doctor',
                self.collected_data,
                'error',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    # async def _get_time_step(self, input_str: str, context: Dict) -> Dict:
    #     """Handle time selection step"""
    #     if not input_str.strip():
    #         return {
    #             "output": "Please specify your preferred time from the available slots.",
    #             "current_step": "get_time",
    #             "collected_data": self.collected_data,
    #             "status": "in_progress"
    #         }
        
    #     # # Here you could add validation of the selected time
    #     # selected_time = input_str.strip()

    #     time_result = await extract_patient_info(input_str, 'appointment_time', self.collected_data["available_slots"])
    #     if not time_result.get("success"):
    #         return {
    #             "output": f"Couldn't find appointment time: {time_result.get('value', 'Unknown error')}",
    #             "current_step": "get_time",
    #             "collected_data": self.collected_data,
    #             "status": "in_progress"
    #         }

    #     self.collected_data["selected_time"] = time_result.get("value")
    #     return {
    #         "output": f"Whats the reason of Appointment ?",
    #         "current_step": "get_reason",
    #         "collected_data": self.collected_data,
    #         "current_tool":"booking_appointment",
    #         "status": "in_progress"
    #     }

    # async def _get_reason_step(self, input_str: str, context: Dict) -> Dict:
    #     """Handle reason selection step"""
    #     if not input_str.strip():
    #         return {
    #             "output": "Please provide a reason for your appointment.",
    #             "current_step": "get_reason",
    #             "collected_data": self.collected_data,
    #             "status": "in_progress"
    #         }
    #     reason_result = await extract_patient_info(input_str, 'reason')
    #     if not reason_result.get("success"):
    #         return {
    #             "output": f"Couldn't find reason: {reason_result.get('value', 'Unknown error')}",
    #             "current_step": "get_reason",
    #             "collected_data": self.collected_data,  
    #             "status": "in_progress"
    #         }
        
    #     self.collected_data["reason"] = reason_result.get("value")
    #     return {
    #         "output": f"Do you want an appointment with Dr. {context.get('doctor')} "
    #                      f"at {context.get('selected_time')}? (yes/no)",
    #         "current_step": "confirm_booking",
    #         "collected_data": self.collected_data,
    #         "current_tool":"booking_appointment",

    #         "status": "in_progress"
    #     }
    # async def _confirm_step(self, input_str: str, context: Dict) -> Dict:
    #     """Handle confirmation step"""
    #     result = await extract_patient_info(input_str, 'confirmation')
    #     if not result.get("success"):
    #         return {
    #             "output": "Booking cancelled. How can I assist you?",
    #             "current_step": "get_doctor",
    #             "collected_data": {},
    #             "status": "in_progress"
    #         }
    #     self.collected_data["confirmation"]= result["value"]
    #     return {
    #             "output": "What's your Phone Number",
    #             "current_step": "assure_registration",
    #             "collected_data": self.collected_data, 
    #             "current_tool":"booking_appointment",
      
    #             "status": "in_progress"
    #         }
    

    
    # async def _complete_booking(self, context: Dict) -> Dict:
    #     """Finalize appointment booking"""
    #     try:
    #         booking_data = {
    #             "doctor_id": context["doctor_id"],
    #             "patient_id": context["patient_id"],
    #             "reason": context["reason"],
    #             "selected_time": context["selected_time"]
    #         }
            
    #         booking_result = await create_appointment_record(booking_data)
            
    #         if booking_result.get("success"):
    #             appointment_id = booking_result['value'].data[0]['appointment_id']
    #             return {
    #                 "output": (
    #                     f"Success! Your appointment with Dr. {context['doctor']} "
    #                     f"at {context['selected_time']} is confirmed. "
    #                     f"Appointment ID: {appointment_id}"
    #                 ),
    #                 "current_step": None,
    #                 "collected_data": {},
    #                 "status": "completed"
    #             }
                
    #         return {
    #             "output": f"Booking failed: {booking_result.get('value', 'Unknown error')}",
    #             "current_step": "confirm_booking",
    #             "collected_data": context,
    #             "current_tool":"booking_appointment",

    #             "status": "error"
    #         }
            
    #     except Exception as e:
    #         logger.error(f"Booking completion error: {str(e)}")
    #         return {
    #             "output": "System error during booking",
    #             "current_step": "confirm_booking",
    #             "collected_data": context,
    #             "status": "error"
    #         }    

    async def _get_time_step(self, input_str: str, context: Dict) -> Dict:
        """Handle time selection step with validation and metrics"""
        step_start_time = time.time()
        subactions = []

        try:
            input_str = str(input_str).strip() if input_str else ""
            
            if not input_str:
                return _build_response(
                    "Please specify your preferred time from the available slots.",
                    'get_time',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Extract and validate time
            llm_start = time.time()
            time_result = await extract_patient_info(input_str, 'appointment_time', self.collected_data["available_slots"])
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_appointment_time",
                "reason": time_result["value"],
                "success": time_result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not time_result['success']:
                return _build_response(
                    f"Couldn't find appointment time: {time_result.get('value', 'Unknown error')}",
                    'get_time',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            self.collected_data["selected_time"] = time_result['value']
            return _build_response(
                "What's the reason for your appointment?",
                'get_reason',
                self.collected_data,
                # 'in_progress',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in time selection step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_time_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing your time selection. Please try again.",
                'get_time',
                self.collected_data,
                # 'error',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _get_reason_step(self, input_str: str, context: Dict) -> Dict:
        """Handle reason collection step with validation"""
        step_start_time = time.time()
        subactions = []

        try:
            input_str = str(input_str).strip() if input_str else ""
            
            if not input_str:
                return _build_response(
                    "Please provide a reason for your appointment.",
                    'get_reason',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Extract reason
            llm_start = time.time()
            reason_result = await extract_patient_info(input_str, 'reason')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_appointment_reason",
                "reason": reason_result["value"],
                "success": reason_result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not reason_result['success']:
                return _build_response(
                    f"Couldn't understand reason: {reason_result.get('value', 'Unknown error')}",
                    'get_reason',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            self.collected_data["reason"] = reason_result['value']
            confirmation_msg = (
                f"Do you want an appointment with Dr. {context.get('doctor')} "
                f"at {context.get('selected_time')}? (yes/no)"
            )

            return _build_response(
                confirmation_msg,
                'confirm_booking',
                self.collected_data,
                # 'in_progress',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in reason step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_reason_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing your reason. Please try again.",
                'get_reason',
                self.collected_data,
                'error',
                "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _confirm_step(self, input_str: str, context: Dict) -> Dict:
        """Handle booking confirmation with proper response structure"""
        step_start_time = time.time()
        subactions = []

        try:
            # Extract confirmation
            llm_start = time.time()
            result = await extract_patient_info(input_str, 'confirmation')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_confirmation",
                "reason": result["value"],
                "success": result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not result['success'] or result['value'].lower() != 'yes':
                return _build_response(
                    "Booking cancelled. How can I assist you?",
                    'get_doctor',
                    {},
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            self.collected_data["confirmation"] = result['value']
            return _build_response(
                "What's your Phone Number?",
                'assure_registration',
                self.collected_data,
                # 'in_progress',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in confirmation step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_confirmation_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred during confirmation. Please try again.",
                'confirm_booking',
                self.collected_data,
                'error',
                "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _complete_booking(self, context: Dict) -> Dict:
        """Finalize appointment booking with proper metrics and error handling"""
        step_start_time = time.time()
        subactions = []

        try:
            booking_data = {
                "doctor_id": context["doctor_id"],
                "patient_id": context["patient_id"],
                "reason": context["reason"],
                "selected_time": context["selected_time"]
            }
            
            # Create booking record
            db_start = time.time()
            booking_result = await create_appointment_record(booking_data)
            db_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "create_appointment",
                "success": booking_result.get("success", False),
                "reason": booking_result.get("message", "Appointment creation"),
                "duration_ms": round((db_end - db_start) * 1000, 2)
            })

            if booking_result.get("success"):
                appointment_id = booking_result['value'].data[0]['appointment_id']
                success_msg = (
                    f"Success! Your appointment with Dr. {context['doctor']} "
                    f"at {context['selected_time']} is confirmed. "
                    f"Appointment ID: {appointment_id}"
                )
                
                return _build_response(
                    success_msg,
                    None,
                    {},
                    'resolved',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            return _build_response(
                f"Booking failed: {booking_result.get('value', 'Unknown error')}",
                'confirm_booking',
                context,
                'error',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Booking completion error: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_booking_completion",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "System error during booking",
                'confirm_booking',
                context,
                'error',
                # "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )
        
    # async def _assure_registration(self, input_str: str, context: Dict) -> Dict:
    #       #adding the logic of registering patient 
    #     #here i will inquire about the pateint phone_number and match with existing in db , if i found any then i will extract
    #     #  
    #     #patient id fro it and pass below , if it doesnot exist then iwill call the registratoin tool and make such mechanisim that 
    #     #it should come back to the same point and we create its record and just show appoitnemnt booked successfully
        
    #     if not input_str.strip():
    #         return {
    #             "output": "What's your Phone Number",
    #             "current_step": "assure_registration",
    #             "collected_data": self.collected_data,       
    #             "status": "in_progress"
    #         }
    #     # phone_number = context.get("phone_number")
    #     # if phone_number:
    #     result = await extract_patient_info(input_str, 'phone_number')
    #     # else:
    #     #     result = await extract_patient_info(input_str, 'phone_number')
            
    #     if not result.get("success"):
    #         return {
    #             "output": "Please tell correct Phone Number",
    #             "current_step": "assure_registration",
    #             "collected_data": self.collected_data,       
    #             "status": "in_progress"
    #         }  
    #     response = await extract_patient_details(result["value"]) 


    #     #here we will make chnges like , call regsiter tool and getting
    #     if not response["success"]:
    #         # patient not found, switch to registration flow
    #         # self.collected_data['registration_flow'] = True
    #         return {
    #             "output": "Let's get you registered. What's your name?",
    #             "current_step": "registering",
    #             "collected_data": self.collected_data,

    #             "current_tool":"booking_appointment",

    #             "status": "in_progress"
    #         }

    #     if response["success"]:
    #         print("already registerd with patient id",response["value"])

    #     self.collected_data["patient_id"] = response["value"]

    #     return await self._complete_booking(self.collected_data)
        


    # async def _handle_registering_step(self, input_str: str, context: Dict[str, Any]) -> Dict:

    #     result =await run_register_patient(input_str, context)
        
    #     # Still registering
    #     if result["status"] == "in_progress":
    #         return {
    #             "output": result["output"],
    #             "current_step": "registering",
    #             "collected_data":self.collected_data,
    #             "sub_step": result["current_step"],
    #             "collected_sub_step_data":result["collected_data"],
    #             "current_tool":"booking_appointment",
    #             "status": "in_progress"
    #         }
        
    #     # Registration completed, return to booking
    #     if result["status"] == "complete":
    #         self.collected_data["patient_id"]=result["output"]
    #         # self.collected_data["registered"]=True
    #         return await self._complete_booking(self.collected_data)


    #     # Registration failed
    #     return {
    #         "output": result["output"],
    #         "current_step": "registering",
    #         "collected_data": result.get("collected_data", context),
    #         "status": "error"
    #     }
    
    async def _assure_registration(self, input_str: str, context: Dict) -> Dict:
        """Handle patient verification/registration with metrics and error handling"""
        step_start_time = time.time()
        subactions = []

        try:
            input_str = str(input_str).strip() if input_str else ""
            
            if not input_str:
                return _build_response(
                    "What's your phone number?",
                    'assure_registration',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Extract phone number
            llm_start = time.time()
            result = await extract_patient_info(input_str, 'phone_number')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_phone_number",
                "reason": result["value"],
                "success": result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not result['success']:
                return _build_response(
                    "Please provide a valid phone number",
                    'assure_registration',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Check patient existence
            db_start = time.time()
            response = await extract_patient_details(result["value"])
            db_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "check_patient_existence",
                "success": response['success'],
                "reason": response.get("message", "Patient lookup"),
                "duration_ms": round((db_end - db_start) * 1000, 2)
            })
            
            self.collected_data['phone_number']=result["value"]
            if not response['success']:
                # Patient not found - initiate registration flow
                return _build_response(
                    "Let's get you registered. What's your full name?",
                    'registering',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Patient exists - store ID and complete booking
            logger.info(f"Patient already registered with ID: {response['value']}")
            self.collected_data["patient_id"] = response['value']
            
            return await self._complete_booking(self.collected_data)

        except Exception as e:
            logger.error(f"Error in registration assurance step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_registration_assurance",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while verifying your registration. Please try again.",
                'assure_registration',
                self.collected_data,
                'error',
                "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )
    # async def _handle_registering_step(self, input_str: str, context: Dict[str, Any]) -> Dict:

        #     result =await run_register_patient(input_str, context)
            
        #     # Still registering
        #     if result["status"] == "in_progress":
        #         return {
        #             "output": result["output"],
        #             "current_step": "registering",
        #             "collected_data":self.collected_data,
        #             "sub_step": result["current_step"],
        #             "collected_sub_step_data":result["collected_data"],
        #             "current_tool":"booking_appointment",
        #             "status": "in_progress"
        #         }
            
        #     # Registration completed, return to booking
        #     if result["status"] == "complete":
        #         self.collected_data["patient_id"]=result["output"]
        #         # self.collected_data["registered"]=True
        #         return await self._complete_booking(self.collected_data)


        #     # Registration failed
        #     return {
        #         "output": result["output"],
        #         "current_step": "registering",
        #         "collected_data": result.get("collected_data", context),
        #         "status": "error"
        #     }
    async def _handle_registering_step(self, input_str: str, context: Dict[str, Any]) -> Dict:
        """Handle patient registration sub-flow with proper response structure"""
        step_start_time = time.time()
        subactions = []

        try:
            # Execute registration tool
            tool_start = time.time()
            result = await run_register_patient(input_str, context)
            tool_end = time.time()

            subactions.append({
                "action_type": "tool",
                "action_name": "patient_registration",
                "success": result['status'] != 'error',
                "reason": result.get("output", "Registration attempt"),
                "duration_ms": round((tool_end - tool_start) * 1000, 2)
            })

            # Still in registration process
            if result["status"] == "in_progress":
                return _build_response(
                    result["output"],
                    'registering',
                    self.collected_data,
                    # 'in_progress',
                    # "booking_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2),
                        "registration_substep": result["current_step"],
                        "registration_data": result["collected_data"]
                    }
                )
            
            # Registration completed successfully
            if result["status"] == "complete":
                self.collected_data["patient_id"] = result["output"]
                return await self._complete_booking(self.collected_data)

            # Registration failed
            return _build_response(
                result["output"],
                'registering',
                result.get("collected_data", context),
                'error',
                "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in registration handling step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_registration_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred during registration. Please try again.",
                'registering',
                self.collected_data,
                'error',
                "booking_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )
    
    async def handle_query(self, input_str: str, context: Dict[str, Any]) -> Dict:
        """Main query handler with state machine"""
        self.current_step = context.get("current_step", "get_doctor")
        self.collected_data = context.get("collected_data", {})
        
        try:
            if self.current_step == "get_doctor":
                return await self._get_doctor_step(input_str)
            elif self.current_step == "get_time":
                return await self._get_time_step(input_str, self.collected_data)
            elif self.current_step == "get_reason":
                return await self._get_reason_step(input_str, self.collected_data)
            elif self.current_step == "confirm_booking":
                return await self._confirm_step(input_str, self.collected_data)
            elif self.current_step == "assure_registration":
                return await self._assure_registration(input_str, self.collected_data)
            elif self.current_step == "registering":
                return await self._handle_registering_step(input_str,context)

            
            else:
                raise ValueError(f"Unknown step: {self.current_step}")
                
        except Exception as e:
            logger.error(f"Step {self.current_step} error: {str(e)}")
            return {
                "output": f"System error in {self.current_step} step. Let's start over.",
                "current_step": "get_doctor",
                "status": "error"
            }
        
def run_book_appointment(input: Union[str, Dict[str, Any]]) -> str:
    """Sync wrapper for appointment booking tool"""
    try:
        # Handle both string and dict input
        if isinstance(input, str):
            try:
                input = json.loads(input)
            except json.JSONDecodeError:
                input = {"query_text": input, "context": {}}
        
        query_text = input.get("query_text", "")
        context = input.get("context", {})
                
        tool_decison_start_time = context.get("tool_decison_start_time", '')

        if tool_decison_start_time:
            decision_duration_ms = (time.time() - float(tool_decison_start_time)) * 1000
        else:
            decision_duration_ms = None

        result = asyncio.run(AppointmentBookingTool().invoke(query_text, context))
        
        result['decision_duration_ms'] = decision_duration_ms
        result['current_tool'] = "booking_appointment"
        
        return json.dumps(result)
    except Exception as e:
        logger.error(f"Error in run_book_appointment: {str(e)}")
        return json.dumps({
            "output": f"Booking error: {str(e)}",
            "current_step": "get_doctor",
            "collected_data": {},
            "status": "error"
        })
# def run_book_appointment(input: Union[str, Dict[str, Any]]) -> str:
#     """Sync wrapper with improved error handling and format validation"""
#     try:
#         # Handle both formats
#         if isinstance(input, dict) and "input" in input:
#             # New format with input wrapper
#             data = input["input"]
#         else:
#             # Old format without wrapper
#             data = input
            
#         # Input parsing (keep original)
#         if isinstance(input, str):
#             try:
#                 input = json.loads(input)
#             except json.JSONDecodeError:
#                 input = {"query_text": input, "context": {}}
        
#         # Add format validation layer
#         if isinstance(input, dict) and "input" in input:
#             # New nested format: {"input": {"query_text":..., "context":...}}
#             if not isinstance(input["input"], dict):
#                 raise ValueError("Nested 'input' must be a dictionary")
#             query_text = input["input"].get("query_text", "")
#             context = input["input"].get("context", {})
#         else:
#             # Original flat format: {"query_text":..., "context":...}
#             query_text = input.get("query_text", "")
#             context = input.get("context", {})
        
#         # Original validation (keep unchanged)
#         if not isinstance(input, dict) or "query_text" not in input:
#             raise ValueError("Invalid input format")
                        
#         tool_decison_start_time = context.get("tool_decison_start_time",'')

#         if tool_decison_start_time:
#             decision_duration_ms = (time.time() - float(tool_decison_start_time)) * 1000
#         else:
#             decision_duration_ms = None
#         # Original async execution (keep unchanged)
#         result = asyncio.run(
#             AppointmentBookingTool().invoke(
#                 query_text,
#                 context
#             )
#         )
#         result['decision_duration_ms'] = decision_duration_ms
#         result['current_tool']="booking_appointment"
#         return json.dumps(result)
        
#     except Exception as e:
#         logger.error(f"Booking tool error: {str(e)}")
#         return json.dumps({
#             "output": f"Booking system error: {str(e)}",
#             "status": "error",
#             "current_step": "get_doctor",
#             "collected_data": {}
#         })
book_appointment_tool = StructuredTool.from_function(
    func=run_book_appointment,
    name="book_appointment_tool",
    description=(
        "Use this tool book an appointment."
    ),
    # args_schema=AppointmentBookingInput,
    return_direct=True
)

__all__ = ["book_appointment_tool"]