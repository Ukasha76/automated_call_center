from agents.sql.tools.functions.doctor_details.extract_doctor_details import extract_doctor_details
from agents.sql.tools.functions.register_patient.extract_patient_info import extract_patient_info
from agents.sql.tools.functions.find_best_match import find_best_match
from agents.sql.tools.functions._build_response import _build_response
from langchain.tools import StructuredTool
from typing import Dict, Any, Union
import asyncio
import json
import logging
import time
import time
from datetime import datetime
from typing import Dict
import uuid

logger = logging.getLogger(__name__)

class DoctorInfoTool:

    async def get_doctor_info(self, name: str, context: Dict = None) -> Dict:

        context = context or {}


        step_start_time = time.time()

        subactions = []

        try:
            # 1. Extract doctor name using LLM
            llm_start = time.time()
            name_extracted = await extract_patient_info(name, 'doctor_name')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_doctor_name",
                "reason":name_extracted["value"],
                "success": name_extracted['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not name_extracted['success']:
                return _build_response(
                    name_extracted["value"],
                    "get_doctor",
                    {},
                    "in_progress",
                    # "doctor_info",
                    step_metrics={"subactions": subactions , "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)}
                )

            # 2. Find best DB match
            db1_start = time.time()
            result = await find_best_match(name_extracted['value'])
            db1_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "find_best_match",
                "success": result['success'],
                "reason":result['name'],
                "duration_ms": round((db1_end - db1_start) * 1000, 2)
            })

            if not result['success']:
                return _build_response(
                    "No doctor found with provided name. Please try again.",
                    "get_doctor",
                    {},
                    "in_progress",
                    # "doctor_info",
                    step_metrics={"subactions": subactions,"step_duration_ms": round((time.time() - step_start_time) * 1000, 2)}
                )

            # 3. Extract doctor details
            db2_start = time.time()
            raw_details = await extract_doctor_details(result['name'])
            db2_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "extract_doctor_details",
                "success": raw_details['success'],
                "reason":raw_details['value'],
                "duration_ms": round((db2_end - db2_start) * 1000, 2)
            })

            details = raw_details.get('value', {})

            spoken_text = (
                f"Here is the doctor information you requested. "
                f"Doctor {details.get('name', 'Name not available')} specializes in {details.get('specialization', 'a medical field')}. "
                f"They are part of the {details.get('department', 'unspecified department')} department. "
                f"You can reach them at extension {details.get('extension', 'not available')} "
                f"or by email at {details.get('email', 'no email available')}."
            )

            return _build_response(
                spoken_text,
                "get_doctor",
                {"doctor": details},
                "resolved",
                # "doctor_info",
                step_metrics={
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2),
                    "subactions": subactions
                }
            )

        except Exception as e:
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_get_doctor_info",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                f"Error: {str(e)}",
                "get_doctor",
                {},
                "error",
                # "doctor_info",
                step_metrics={
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2),
                    "subactions": subactions
                }
            )

    async def invoke(self, name: str, context: Dict = None) -> Dict:
        

        return await self.get_doctor_info(name, context)



# Tool instance
doctor_info_tool_instance = DoctorInfoTool()

# Sync wrapper
def run_doctor_info(input: Union[str, Dict[str, Any]]) -> str:
    try:
        if isinstance(input, str):
            try:
                input = json.loads(input)
            except json.JSONDecodeError:
                input = {"query_text": input, "context": {} }

        query_text = input.get("query_text", "")
        context = input.get("context", {})

        tool_decison_start_time = context.get("tool_decison_start_time",'')

        if tool_decison_start_time:
            decision_duration_ms = (time.time() - float(tool_decison_start_time)) * 1000
        else:
            decision_duration_ms = None

        result = asyncio.run(doctor_info_tool_instance.invoke(query_text, context))


        result['decision_duration_ms'] = decision_duration_ms
        result['current_tool']='doctor_details'

        return json.dumps(result)
    except Exception as e:
        logger.error(f"Error in run_doctor_info: {str(e)}")
        return json.dumps({
            "output": f"Doctor info error: {str(e)}",
            "current_step": "get_doctor",
            "collected_data": {},
            "status": "error"
        })


# LangChain tool
doctor_info_tool = StructuredTool.from_function(
    func=run_doctor_info,
    name="Doctor Info",
    description=(
        "Use this tool to provide doctor info . The input will include , query_text and context"
    ),
    return_direct=True
)

__all__ = ["doctor_info_tool"]
