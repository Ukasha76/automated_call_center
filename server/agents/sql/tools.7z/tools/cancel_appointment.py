from agents.sql.tools.functions.cancel_appointment.extract_appointment_details import extract_appointment_details
# from agents.sql.tools.functions.cancel_appointment.validate_appointment_details import validate_appointment_details
from agents.sql.tools.functions.cancel_appointment.delete_appointment_record import delete_appointment_record
from agents.sql.tools.functions.register_patient.extract_patient_info import extract_patient_info
from langchain.tools import Tool
from typing import Dict, Any
import logging
from agents.sql.tools.functions._build_response import _build_response

from langchain.tools import StructuredTool
import random
import string
import logging
import asyncio
import re
import json
import time
from typing import Optional, Tuple

from typing import Union  
logger = logging.getLogger(__name__)

def extract_appointment_id(query: str) -> Optional[str]:
        """
        Extracts appointment ID from user query.
        
        Args:
            query: User's natural language input (e.g., "cancel appointment 123456")
            
        Returns:
            Extracted appointment ID string if found, None otherwise
        """
        if not query or not isinstance(query, str):
            return None
            
        # Common patterns to match appointment IDs
        patterns = [
            r'appointment\s*(?:id|number|no|#)?\s*(?:is|:)?\s*(\d+)',  # "appointment id 123"
            r'my\s+appointment\s*(?:is|:)?\s*(\d+)',  # "my appointment 123"
            r'cancel\s+(?:appointment)?\s*(\d+)',     # "cancel 123"
            r'(\d{6,})'                               # Standalone 6+ digit number
        ]
        
        cleaned_query = ' '.join(query.strip().split())  # Normalize whitespace
        
        for pattern in patterns:
            match = re.search(pattern, cleaned_query, re.IGNORECASE)
            if match:
                extracted_id = match.group(1)
                return extracted_id
                    
        return None
class AppointmentCancellationTool:
    def __init__(self):
        self.current_step = "get_appointment_id"
        self.collected_data = {}

    async def invoke(self, input_data: Any, context: Dict = None) -> Dict:
        """Main entry point that matches LangChain's expected interface"""
        try:
            safe_input = self._normalize_input(input_data)
            query = str(safe_input['query_text'])
            ctx = safe_input.get('context', {}) or (context if isinstance(context, dict) else {})
            
            
            return await self.handle_query(query, ctx)
        
        except Exception as e:
            logger.error(f"Invoke error: {str(e)}", exc_info=True)
            return {
                "output": f"System error: {str(e)}",
                "status": "error",
                "debug": {
                    "input_received": str(input_data)[:100],
                    "input_type": str(type(input_data))
                }
            }   
    def _normalize_input(self, input_data: Any) -> Dict[str, Any]:
        """Convert any input type to safe dictionary format"""
        # Handle primitive types
        if isinstance(input_data, (int, float)):
            return {"query_text": str(input_data), "context": {}}
        
        # Handle strings (could be JSON)
        if isinstance(input_data, str):
            try:
                data = json.loads(input_data)
                if isinstance(data, dict):
                    return data
                return {"query_text": str(data), "context": {}}
            except json.JSONDecodeError:
                return {"query_text": input_data, "context": {}}
        
        # Handle dictionaries
        if isinstance(input_data, dict):
            return {
                "query_text": str(input_data.get('query_text', input_data.get('input_data', ''))),
                "context": input_data.get('context', {})
            }
        
        # Fallback for any other type
        return {"query_text": str(input_data), "context": {}}

    async def handle_query(self, input_str: str, context: Dict[str, Any]) -> Dict:
        """
        Handles the appointment cancellation process.
        Returns dict with:
        - response: string for user
        - current_step: next step identifier
        - collected_data: updated context
        - status: 'in_progress'|'complete'|'error'
        """
        self.current_step = context.get('current_step', 'get_appointment_id')
        self.collected_data = context.get('collected_data', {})

        try:
            if self.current_step == 'get_appointment_id':
                return await self._handle_appointment_id_step(input_str)
            elif self.current_step == 'confirm_cancellation':
                return await self._handle_confirmation_step(input_str)
            else:
                return self._reset_flow("Let's start over. Please provide your patient ID.")
                
        except Exception as e:
            logger.error(f"Cancellation error: {str(e)}")
            return self._reset_flow("I encountered an error. Let's start over.")

    async def _handle_appointment_id_step(self, input_str: str) -> Dict:
        """Handle appointment ID input step with validation and error handling.
        
        Args:
            input_str: The user-provided appointment ID
            
        Returns:
            Dictionary with:
            - response: Message to display to user
            - current_step: Next step in workflow
            - collected_data: Updated context data
            - status: Current status of workflow
        """
        step_start_time = time.time()
        subactions = []

        try:
            # Clean and validate input
            input_str = str(input_str).strip() if input_str else ""
            
            if not input_str:
                return _build_response(
                    "Please provide your appointment ID.",
                    'get_appointment_id',
                    self.collected_data,
                    'in_progress',
                    # "cancel_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Extract appointment ID
            llm_start = time.time()
            extracted_id = await extract_patient_info(input_str, 'appointment_id')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_appointment_id",
                "reason": extracted_id["value"],
                "success": extracted_id['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            # Validate appointment ID format if needed
            if not extracted_id['success']:
                return _build_response(
                    f"Please provide your appointment ID.",
                    'get_appointment_id',
                    self.collected_data,
                    'in_progress',
                    # "cancel_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Get appointment details
            db_start = time.time()
            details_result = await extract_appointment_details(extracted_id['value'])
            db_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "extract_appointment_details",
                "success": details_result['success'],
                "reason": details_result['value'],
                "duration_ms": round((db_end - db_start) * 1000, 2)
            })
            
            if not details_result['success']:
                logger.warning(f"Failed to fetch appointment details for ID: {input_str}")
                return _build_response(
                    details_result['value'],
                    'get_appointmnet_id',
                    self.collected_data,
                    'in_progress',
                    # "cancel_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Store data for confirmation step
            self.collected_data.update({
                'appointment_id': details_result["appointment_id"],
                'formatted_details': details_result['value']   # Store formatted string
            })

            # Build confirmation prompt
            confirmation_prompt = (
                f"{details_result['value']}\n\n"
                "Are you sure you want to cancel this appointment? (yes/no)"
            )

            return _build_response(
                confirmation_prompt,
                'confirm_cancellation',
                self.collected_data,
                'in_progress',
                # "cancel_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in appointment ID step: {str(e)}", exc_info=True)
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_appointment_id_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing your request. Please try again.",
                'get_appointment_id',
                {},
                'error',
                # "cancel_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _handle_confirmation_step(self, input_str: str) -> Dict:
        """Handle confirmation step"""
        step_start_time = time.time()
        subactions = []

        try:
            # Extract confirmation response
            llm_start = time.time()
            result = await extract_patient_info(input_str, 'confirmation')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_confirmation",
                "reason": result["value"],
                "success": result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not result['success']:
                return _build_response(
                    result['value'],
                    'confirm_rescheduling',
                    self.collected_data,
                    'error',
                    # "cancel_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            if result['value'] == "No":
                return self._reset_flow(
                    "Rescheduling aborted. Let's start over if you want to try again.",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            try:
                # Cancel appointment
                db_start = time.time()
                result = await delete_appointment_record(self.collected_data['appointment_id'])
                db_end = time.time()

                subactions.append({
                    "action_type": "db",
                    "action_name": "delete_appointment",
                    "success": result['success'],
                    "reason": result['value'],
                    "duration_ms": round((db_end - db_start) * 1000, 2)
                })

                if not result['success']:
                    return _build_response(
                        result['value'],
                        'get_appointmnet_id',
                        {},
                        'error',
                        # "cancel_appointment",
                        step_metrics={
                            "subactions": subactions,
                            "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                        }
                    )
                
                return _build_response(
                    f"Your appointment has been successfully canceled!",
                    None,
                    None,
                    'resolved',
                    # "cancel_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )       

            except Exception as e:
                logger.error(f"Database error: {str(e)}")
                subactions.append({
                    "action_type": "error",
                    "action_name": "exception_in_appointment_cancellation",
                    "success": False,
                    "duration_ms": round((time.time() - step_start_time) * 1000, 2)
                })

                return _build_response(
                    "Sorry, I couldn't cancel your appointment. Please try again.",
                    'get_appointment_id',
                    {},
                    'error',
                    # "cancel_appointment",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

        except Exception as e:
            logger.error(f"Error in confirmation step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_confirmation_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing your confirmation. Please try again.",
                'confirm_cancellation',
                self.collected_data,
                'error',
                # "cancel_appointment",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    def _reset_flow(self, message: str) -> Dict:
        """Reset the cancellation flow"""
        self.current_step = 'get_appointment_id'
        self.collected_data = {}
        return _build_response(
            message,
            'get_appointment_id',
            {},
            status='in_progress'
            
        )       
        

# Create tool instance
cancellation_tool = AppointmentCancellationTool()


def run_cancel_appointment(input: Union[str, Dict[str, Any]]) -> str:
    try:
        # Handle both string and dict input
        if isinstance(input, str):
            try:
                input = json.loads(input)
            except json.JSONDecodeError:
                input = {"query_text": input, "context": {}}
        
        query_text = input.get("query_text", "")
        context = input.get("context", {})
                
        tool_decison_start_time = context.get("tool_decison_start_time",'')

        if tool_decison_start_time:
            decision_duration_ms = (time.time() - float(tool_decison_start_time)) * 1000
        else:
            decision_duration_ms = None

        result = asyncio.run(cancellation_tool.invoke(query_text, context))
        
        
        result['decision_duration_ms'] = decision_duration_ms
        result['current_tool']="cancel_appointment"

        
        return json.dumps(result)
    except Exception as e:
        logger.error(f"Error in run_register_patient: {str(e)}")
        return json.dumps({
            "output": f"Registration error: {str(e)}",
            "current_step": "get_name",
            "collected_data": {},
            "status": "error"
        })
# LangChain tool decorator
cancel_appointment_tool = StructuredTool.from_function(
    func=run_cancel_appointment,
    name="Cancel Appointment",
    description=(
        "Cancel a Patient Appointment based on Appointment_id"
        "Input should be a dictionary with 'query_text' and 'context' or a JSON string."
    ),
    return_direct=True
)

__all__ = ["cancel_appointment_tool"]
