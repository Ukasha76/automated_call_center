from agents.sql.tools.functions.prescription_refill.extract_prescription_details import extract_prescription_details
from agents.sql.tools.functions.prescription_refill.update_prescription_record import update_prescription_record
from agents.sql.tools.functions.register_patient.extract_patient_info import extract_patient_info
from agents.sql.tools.functions._build_response import _build_response

from langchain.tools import StructuredTool
from typing import Dict, Any, Optional, Union
import json
import logging
import asyncio
import re
import time

logger = logging.getLogger(__name__)

class PrescriptionRefillTool:
    def __init__(self):
        self.current_step = "get_prescription_id"
        self.collected_data = {}

    async def invoke(self, input_data: Any, context: Dict = None) -> Dict:
        try:
            safe_input = self._normalize_input(input_data)
            query = str(safe_input['query_text'])
            ctx = safe_input.get('context', {}) or (context if isinstance(context, dict) else {})
            return await self.handle_query(query, ctx)
        except Exception as e:
            logger.error(f"Invoke error: {str(e)}", exc_info=True)
            return {
                "output": f"System error: {str(e)}",
                "status": "error",
                "debug": {
                    "input_received": str(input_data)[:100],
                    "input_type": str(type(input_data))
                }
            }

    def _normalize_input(self, input_data: Any) -> Dict[str, Any]:
        if isinstance(input_data, (int, float)):
            return {"query_text": str(input_data), "context": {}}
        if isinstance(input_data, str):
            try:
                data = json.loads(input_data)
                if isinstance(data, dict):
                    return data
                return {"query_text": str(data), "context": {}}
            except json.JSONDecodeError:
                return {"query_text": input_data, "context": {}}
        if isinstance(input_data, dict):
            return {
                "query_text": str(input_data.get('query_text', input_data.get('input_data', ''))),
                "context": input_data.get('context', {})
            }
        return {"query_text": str(input_data), "context": {}}

    async def handle_query(self, input_str: str, context: Dict[str, Any]) -> Dict:
        self.current_step = context.get('current_step', 'get_prescription_id')
        self.collected_data = context.get('collected_data', {})

        try:
            if self.current_step == 'get_prescription_id':
                return await self._handle_prescription_id_step(input_str)
            elif self.current_step == 'confirm_refill':
                return await self._handle_confirmation_step(input_str)
            else:
                return self._reset_flow("Let's start over. Please provide your prescription ID.")
        except Exception as e:
            logger.error(f"Refill error: {str(e)}")
            return self._reset_flow("I encountered an error. Let's start over.")
    async def _handle_prescription_id_step(self, input_str: str) -> Dict:
        step_start_time = time.time()
        subactions = []

        try:
            input_str = str(input_str).strip()
            if not input_str:
                return _build_response(
                    "Please provide your prescription ID.", 
                    'get_prescription_id',
                    self.collected_data,
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            # Extract prescription ID
            llm_start = time.time()
            extracted_id = await extract_patient_info(input_str, 'prescription_id')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_prescription_id",
                "reason": extracted_id["value"],
                "success": extracted_id['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not extracted_id['success']:
                return _build_response(
                    "Invalid prescription id. Please provide your prescription ID.", 
                    'get_prescription_id',
                    self.collected_data,
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            # Get prescription details
            db_start = time.time()
            details_result = await extract_prescription_details(extracted_id['value'])
            db_end = time.time()

            subactions.append({
                "action_type": "db",
                "action_name": "extract_prescription_details",
                "success": details_result['success'],
                "reason": details_result['value'],
                "duration_ms": round((db_end - db_start) * 1000, 2)
            })

            if not details_result['success'] and not details_result['refills_remaining']:
                return _build_response(
                    'No refills left. Please visit hospital', 
                    '', 
                    '', 
                    'resolved',
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            if not details_result['success']:
                logger.warning(f"No prescription id found in record. Give correct prescription id please: {input_str}")
                return _build_response(
                    details_result['value'], 
                    'get_prescription_id',
                    self.collected_data,
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            # Store all relevant details from the response in session
            self.collected_data.update({
                "prescription_id": details_result["prescription_id"],
                "patient_id": details_result["patient_id"],
                "patient_name": details_result["patient_name"],
                "doctor_name": details_result["doctor_name"],
                "medication_name": details_result["medication_name"],
                "dosage": details_result["dosage"],
                "start_date": details_result["start_date"],
                "end_date": details_result["end_date"],
                "refills_allowed": details_result["refills_allowed"],
                "refills_remaining": details_result["refills_remaining"]
            })

            confirmation_prompt = (
                f"{details_result['value']}\n\n"
                "Do you want to proceed with refilling this prescription? (yes/no)"
            )

            return _build_response(
                confirmation_prompt, 
                'confirm_refill',
                self.collected_data,
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            logger.error(f"Error in prescription ID step: {str(e)}", exc_info=True)
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_prescription_id_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing your request. Please try again.",
                'get_prescription_id',
                status='error',
                
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _handle_confirmation_step(self, input_str: str) -> Dict:
        step_start_time = time.time()
        subactions = []

        try:
            # Extract confirmation response
            llm_start = time.time()
            result = await extract_patient_info(input_str, 'confirmation')
            llm_end = time.time()

            subactions.append({
                "action_type": "llm",
                "action_name": "extract_confirmation",
                "reason": result["value"],
                "success": result['success'],
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not result['success']:
                return _build_response(
                    result['value'],
                    'confirm_refill',
                    status='error',
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            
            if result['value'].lower() == "no":
                return self._reset_flow(
                    "Refill canceled. Let me know if you need anything else.",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            try:
                # Update prescription record
                db_start = time.time()
                result = await update_prescription_record(self.collected_data)
                db_end = time.time()

                subactions.append({
                    "action_type": "db",
                    "action_name": "update_prescription_record",
                    "success": result['success'],
                    "reason": result['value'],
                    "duration_ms": round((db_end - db_start) * 1000, 2)
                })

                if not result['success']:
                    return _build_response(
                        result['value'], 
                        'get_prescription_id', 
                        status='error',
                        step_metrics={
                            "subactions": subactions,
                            "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                        }
                    )

                return _build_response(
                    f"Your prescription has been successfully refilled! Your refill id is {result['refill_id']} valid until {result['valid_until']}",
                    '',
                    'None',
                    status='resolved',
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
            except Exception as e:
                logger.error(f"Database error: {str(e)}")
                subactions.append({
                    "action_type": "error",
                    "action_name": "exception_in_prescription_update",
                    "success": False,
                    "duration_ms": round((time.time() - step_start_time) * 1000, 2)
                })

                return _build_response(
                    "Sorry, I couldn't refill your prescription. Please try again.",
                    'get_prescription_id',
                    status='error',
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

        except Exception as e:
            logger.error(f"Error in confirmation step: {str(e)}")
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_confirmation_step",
                "success": False,
                "duration_ms": round((time.time() - step_start_time) * 1000, 2)
            })

            return _build_response(
                "An error occurred while processing your confirmation. Please try again.",
                'confirm_refill',
                status='error',
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    # def _build_response(self, message: str, next_step: str, current_tool: str = 'prescription_refill', status: str = 'in_progress', step_metrics: Dict = None) -> Dict:
    #     response = {
    #         'output': message,
    #         'current_step': next_step,
    #         'collected_data': self.collected_data,
    #         'current_tool': current_tool,
    #         'status': status
    #     }
    #     if step_metrics:
    #         response['step_metrics'] = step_metrics
    #     return response

    def _reset_flow(self, message: str, step_metrics: Dict = None) -> Dict:
        self.current_step = 'get_prescription_id'
        self.collected_data = {}
        return self._build_response(
            message, 
            'get_prescription_id', 
            status='in_progress',
            step_metrics=step_metrics
        )

# Create instance
refill_tool_instance = PrescriptionRefillTool()

def run_prescription_refill(input: Union[str, Dict[str, Any]]) -> str:
    try:
        if isinstance(input, str):
            try:
                input = json.loads(input)
            except json.JSONDecodeError:
                input = {"query_text": input, "context": {}}

        query_text = input.get("query_text", "")
        context = input.get("context", {})
        tool_decison_start_time = context.get("tool_decison_start_time",'')

        if tool_decison_start_time:
            decision_duration_ms = (time.time() - float(tool_decison_start_time)) * 1000
        else:
            decision_duration_ms = None

        result = asyncio.run(refill_tool_instance.invoke(query_text, context))

        result['decision_duration_ms'] = decision_duration_ms

        result['current_tool']='prescription_refill'

        
        return json.dumps(result)
    except Exception as e:
        logger.error(f"Error in run_prescription_refill: {str(e)}")
        return json.dumps({
            "output": f"Refill error: {str(e)}",
            "current_step": "get_prescription_id",
            "collected_data": {},
            "status": "error"
        })

# LangChain tool
prescription_refill_tool = StructuredTool.from_function(
    func=run_prescription_refill,
    name="Refill Prescription",
    description=(
        "Refill a Patient's Prescription based on prescription_id. "
        "Input should be a dictionary with 'query_text' and 'context' or a JSON string."
    ),
    return_direct=True
)

__all__ = ["prescription_refill_tool"]
