from agents.sql.tools.functions.cancel_appointment.extract_appointment_details import extract_appointment_details
from agents.sql.tools.functions.cancel_appointment.delete_appointment_record import delete_appointment_record
from langchain.tools import Tool
from agents.sql.tools.functions._build_response import _build_response

from agents.sql.tools.functions.appointmentSlots_info.get_available_slots import get_available_slots    
from agents.sql.tools.functions.book_appointment.create_appointment_record import create_appointment_record
from agents.sql.tools.functions.register_patient.extract_patient_info import extract_patient_info
from typing import Dict, Any
import logging
from langchain.tools import StructuredTool
import random
import string
import logging
import asyncio
import re
import time
import json
from typing import Optional, Tuple

from typing import Union  
logger = logging.getLogger(__name__)

def extract_appointment_id(query: str) -> Optional[str]:
        """
        Extracts appointment ID from user query.
        
        Args:
            query: User's natural language input (e.g., "cancel appointment 123456")
            
        Returns:
            Extracted appointment ID string if found, None otherwise
        """
        if not query or not isinstance(query, str):
            return None
            
        # Common patterns to match appointment IDs
        patterns = [
            r'appointment\s*(?:id|number|no|#)?\s*(?:is|:)?\s*(\d+)',  # "appointment id 123"
            r'my\s+appointment\s*(?:is|:)?\s*(\d+)',  # "my appointment 123"
            r'cancel\s+(?:appointment)?\s*(\d+)',     # "cancel 123"
            r'(\d{6,})'                               # Standalone 6+ digit number
        ]
        
        cleaned_query = ' '.join(query.strip().split())  # Normalize whitespace
        
        for pattern in patterns:
            match = re.search(pattern, cleaned_query, re.IGNORECASE)
            if match:
                extracted_id = match.group(1)
                return extracted_id
                    
        return None
class AppointmentReschedulingTool:
    def __init__(self):
        self.current_step = "get_appointment_id"
        self.collected_data = {}

    async def invoke(self, input_data: Any, context: Dict = None) -> Dict:
        """Main entry point that matches LangChain's expected interface"""
        try:
            safe_input = self._normalize_input(input_data)
            query = str(safe_input['query_text'])
            ctx = safe_input.get('context', {}) or (context if isinstance(context, dict) else {})
            
            
            return await self.handle_query(query, ctx)
        
        except Exception as e:
            logger.error(f"Invoke error: {str(e)}", exc_info=True)
            return {
                "output": f"System error: {str(e)}",
                "status": "error",
                "debug": {
                    "input_received": str(input_data)[:100],
                    "input_type": str(type(input_data))
                }
            }   
    def _normalize_input(self, input_data: Any) -> Dict[str, Any]:
        """Convert any input type to safe dictionary format"""
        # Handle primitive types
        if isinstance(input_data, (int, float)):
            return {"query_text": str(input_data), "context": {}}
        
        # Handle strings (could be JSON)
        if isinstance(input_data, str):
            try:
                data = json.loads(input_data)
                if isinstance(data, dict):
                    return data
                return {"query_text": str(data), "context": {}}
            except json.JSONDecodeError:
                return {"query_text": input_data, "context": {}}
        
        # Handle dictionaries
        if isinstance(input_data, dict):
            return {
                "query_text": str(input_data.get('query_text', input_data.get('input_data', ''))),
                "context": input_data.get('context', {})
            }
        
        # Fallback for any other type
        return {"query_text": str(input_data), "context": {}}

    async def handle_query(self, input_str: str, context: Dict[str, Any]) -> Dict:
        """
        Handles the appointment cancellation process.
        Returns dict with:
        - response: string for user
        - current_step: next step identifier
        - collected_data: updated context
        - status: 'in_progress'|'complete'|'error'
        """
        self.current_step = context.get('current_step', 'get_appointment_id')
        self.collected_data = context.get('collected_data', {})

        try:
            if self.current_step == 'get_appointment_id':
                return await self._handle_appointment_id_step(input_str)
            elif self.current_step == 'inquire_again':
                return await self._handle_inquire_again_step(input_str,self.collected_data)
            elif self.current_step == 'get_time':
                return await self._handle_time_step(input_str,self.collected_data)
            elif self.current_step == 'confirm_rescheduling':
                return await self._handle_confirmation_step(input_str,self.collected_data)
            else:
                return self._reset_flow("Let's start over. Please provide your patient ID.")
                
        except Exception as e:
            logger.error(f"Cancellation error: {str(e)}")
            return self._reset_flow("I encountered an error. Let's start over.")
    async def _handle_confirmation_step(self, input_str: str, context: Dict) -> Dict:
        """Handle confirmation step"""
        step_start_time = time.time()
        subactions = []
        
        try:
            # Extract confirmation
            llm_start = time.time()
            result = await extract_patient_info(input_str, 'confirmation')
            llm_end = time.time()
            
            subactions.append({
                "action_type": "llm",
                "action_name": "extract_confirmation",
                "success": result['success'],
                "reason": result['value'] if not result['success'] else None,
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not result['success']:
                return _build_response(
                    result['value'],
                    'confirm_rescheduling',
                    {},
                    'error',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
                
            if result['value'] == "No":
                return self._reset_flow(
                    "Rescheduling aborted. Let's start over if you want to try again.",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                ) 
            
            try:
                extracted_id = self.collected_data['appointment_id']

                # Delete old appointment
                db1_start = time.time()
                delete_result = await delete_appointment_record(self.collected_data['appointment_id'])
                db1_end = time.time()
                
                subactions.append({
                    "action_type": "db",
                    "action_name": "delete_appointment",
                    "success": delete_result['success'],
                    "reason": delete_result['value'] if not delete_result['success'] else None,
                    "duration_ms": round((db1_end - db1_start) * 1000, 2),
                })

                # Create new appointment
                db2_start = time.time()
                booking_result = await create_appointment_record({
                    "patient_id": self.collected_data['patient_id'],
                    "doctor_id": self.collected_data['doctor_id'],
                    "selected_time": self.collected_data['selected_time'],
                    "reason": self.collected_data['reason']
                })
                db2_end = time.time()
                
                subactions.append({
                    "action_type": "db",
                    "action_name": "create_appointment",
                    "success": booking_result['success'],
                    "reason": booking_result['value'] if not booking_result['success'] else None,
                    "duration_ms": round((db2_end - db2_start) * 1000, 2),
                })

                if not booking_result['success']:
                    return _build_response(
                        booking_result['value'],
                        'get_appointmnet_id',
                        {},
                        'error',
                        # "appointment_rescheduling",
                        step_metrics={
                            "subactions": subactions,
                            "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                        }
                    )
                
                appointment_id = booking_result.get('value').data[0]['appointment_id']
                
                return _build_response(
                    f"Your appointment has been successfully rescheduled! Your appointment id is {appointment_id}",
                    '',
                    {},
                    'resolved',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )       
            except Exception as e:
                subactions.append({
                    "action_type": "error",
                    "action_name": "exception_in_confirmation_processing",
                    "success": False,
                    "reason": str(e),
                    "duration_ms": round((time.time() - step_start_time) * 1000, 2),
                })
                
                logger.error(f"Error in confirmation step: {str(e)}", exc_info=True)
                return _build_response(
                    "An error occurred while processing your request. Please try again.",
                    'get_appointment_id',
                    {},
                    'error',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
                
        except Exception as e:
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_confirmation_step",
                "success": False,
                "reason": str(e),
                "duration_ms": round((time.time() - step_start_time) * 1000, 2),
            })
            
            logger.error(f"Error in confirmation step: {str(e)}", exc_info=True)
            return _build_response(
                "An error occurred while processing your request. Please try again.",
                'get_appointment_id',
                {},
                'error',
                # "appointment_rescheduling",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _handle_time_step(self, input_str: str, context: Dict) -> Dict:
        """Handle time selection step"""
        step_start_time = time.time()
        subactions = []
        
        try:
            if not input_str.strip():
                return _build_response(
                    "Please specify your preferred time from the available slots.",
                    'get_time',
                    {},
                    'in_progress',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
        
            # Extract time
            llm_start = time.time()
            time_result = await extract_patient_info(input_str, 'appointment_time', self.collected_data["available_slots"])
            llm_end = time.time()
            
            subactions.append({
                "action_type": "llm",
                "action_name": "extract_appointment_time",
                "success": time_result['success'],
                "reason": time_result['value'] if not time_result['success'] else None,
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not time_result.get("success"):
                return _build_response(
                    f"Couldn't find appointment time: {time_result.get('value', 'Unknown error')}",
                    'get_time',
                    self.collected_data,
                    'in_progress',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
                
            self.collected_data["selected_time"] = time_result['value']

            return _build_response(
                f"Do you want an appointment with Dr. {context.get('doctor_name')} "
                             f"at {context.get('selected_time')}? (yes/no)",
                'confirm_rescheduling',
                self.collected_data,
                'in_progress',
                # "appointment_rescheduling",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )        
        except Exception as e:
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_time_step",
                "success": False,
                "reason": str(e),
                "duration_ms": round((time.time() - step_start_time) * 1000, 2),
            })
            
            logger.error(f"Error in time step: {str(e)}", exc_info=True)
            return _build_response(
                "An error occurred while processing your request. Please try again.",
                'get_time',
                {},
                'error',
                # "appointment_rescheduling",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _handle_appointment_id_step(self, input_str: str) -> Dict:
        """Handle appointment ID input step with validation and error handling."""
        step_start_time = time.time()
        subactions = []
        
        try:
            # Clean and validate input
            input_str = str(input_str).strip() if input_str else ""
            
            if not input_str:
                return _build_response(
                    "Please provide your appointment ID.",
                    'get_appointment_id',
                    self.collected_data,
                    'in_progress',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
                
            # Extract appointment ID
            llm_start = time.time()
            extracted_id = await extract_patient_info(input_str, 'appointment_id')
            llm_end = time.time()
            
            subactions.append({
                "action_type": "llm",
                "action_name": "extract_appointment_id",
                "success": extracted_id['success'],
                "reason": extracted_id['value'] if not extracted_id['success'] else None,
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not extracted_id['success']:
                return _build_response(
                    f"Please provide your appointment ID.",
                    'get_appointment_id',
                    self.collected_data,
                    'in_progress',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            self.collected_data.update({
                'appointment_id': extracted_id['value']
            })

            return _build_response(
                "Do you want to reschedule with same doctor? (yes/no)",
                'inquire_again',
                self.collected_data,
                'in_progress',
                # "appointment_rescheduling",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

        except Exception as e:
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_appointment_id_step",
                "success": False,
                "reason": str(e),
                "duration_ms": round((time.time() - step_start_time) * 1000, 2),
            })
            
            logger.error(f"Error in appointment ID step: {str(e)}", exc_info=True)
            return _build_response(
                "An error occurred while processing your request. Please try again.",
                'get_appointment_id',
                {},
                'error',
                # "appointment_rescheduling",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )

    async def _handle_inquire_again_step(self, input_str: str, context: Dict) -> Dict:
        """Handle confirmation step"""
        step_start_time = time.time()
        subactions = []
        
        try:
            # Extract confirmation
            llm_start = time.time()
            result = await extract_patient_info(input_str, 'confirmation')
            llm_end = time.time()
            
            subactions.append({
                "action_type": "llm",
                "action_name": "extract_confirmation",
                "success": result['success'],
                "reason": result['value'] if not result['success'] else None,
                "duration_ms": round((llm_end - llm_start) * 1000, 2),
            })

            if not result['success']:
                return self._reset_flow(
                    "Cancellation aborted. Let's start over if you want to try again.",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
                
            if result['value'] == "No":
                return self._reset_flow(
                    "We currently don't have any other doctors available. Please try again later.",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            try:
                extracted_id = self.collected_data['appointment_id']

                # Get appointment details
                db_start = time.time()
                details_result = await extract_appointment_details(extracted_id)
                db_end = time.time()
                
                subactions.append({
                    "action_type": "db",
                    "action_name": "extract_appointment_details",
                    "success": details_result['success'],
                    "reason": details_result['value'] if not details_result['success'] else None,
                    "duration_ms": round((db_end - db_start) * 1000, 2),
                })

                if not details_result['success']:
                    logger.warning(f"Failed to fetch appointment details for ID: {input_str}")
                    return _build_response(
                        details_result['value'],
                        'get_appointmnet_id',
                        self.collected_data,
                        'in_progress',
                        # "appointment_rescheduling",
                        step_metrics={
                            "subactions": subactions,
                            "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                        }
                    )
                
                self.collected_data.update({
                    'patient_id': details_result['patient_id'],
                    'doctor_id': details_result['doctor_id'],
                    'patient_name': details_result['patient_name'],
                    'doctor_name': details_result['doctor_name'],
                    'day': details_result['day'],
                    'time': details_result['time'],
                    'reason': details_result['reason']
                })

                # Get available slots
                db2_start = time.time()
                available_slots = await get_available_slots(self.collected_data['doctor_id'])
                db2_end = time.time()
                
                subactions.append({
                    "action_type": "db",
                    "action_name": "get_available_slots",
                    "success": available_slots['success'],
                    "reason": "No slots available" if not available_slots['success'] else None,
                    "duration_ms": round((db2_end - db2_start) * 1000, 2),
                })

                if not available_slots['success']:
                    return _build_response(
                        f"No available slots for Dr. {self.collected_data['doctor_name']}",
                        '',
                        {},
                        'resolved',
                        "appointment_rescheduling",
                        step_metrics={
                            "subactions": subactions,
                            "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                        }
                    )
                
                self.collected_data["available_slots"] = available_slots['value']
                slot_str = "\n".join([f"{slot[0]} {slot[1]}" for slot in available_slots['value']])

                return _build_response(
                    f"Available slots for Dr. {self.collected_data['doctor_name']}:\n{slot_str}",
                    'get_time',
                    self.collected_data,
                    'in_progress',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )

            except Exception as e:
                subactions.append({
                    "action_type": "error",
                    "action_name": "exception_in_inquire_again_processing",
                    "success": False,
                    "reason": str(e),
                    "duration_ms": round((time.time() - step_start_time) * 1000, 2),
                })
                
                logger.error(f"Database error: {str(e)}")
                return _build_response(
                    "Sorry, I couldn't cancel your appointment. Please try again.",
                    'get_appointment_id',
                    {},
                    'error',
                    # "appointment_rescheduling",
                    step_metrics={
                        "subactions": subactions,
                        "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                    }
                )
                
        except Exception as e:
            subactions.append({
                "action_type": "error",
                "action_name": "exception_in_inquire_again_step",
                "success": False,
                "reason": str(e),
                "duration_ms": round((time.time() - step_start_time) * 1000, 2),
            })
            
            logger.error(f"Error in inquire again step: {str(e)}", exc_info=True)
            return _build_response(
                "An error occurred while processing your request. Please try again.",
                'get_appointment_id',
                {},
                'error',
                # "appointment_rescheduling",
                step_metrics={
                    "subactions": subactions,
                    "step_duration_ms": round((time.time() - step_start_time) * 1000, 2)
                }
            )
    def _reset_flow(self, message: str) -> Dict:
        """Reset the cancellation flow"""
        self.current_step = 'get_appointment_id'
        self.collected_data = {}
        return _build_response(
            message,
            'get_appointment_id',
            {},
            status='in_progress'
            # "appointment_rescheduling" 
        )       
        

# Create tool instance
rescheduling_appointment = AppointmentReschedulingTool()


def run_rescheduling_appointment(input: Union[str, Dict[str, Any]]) -> str:
    try:
        # Handle both string and dict input
        if isinstance(input, str):
            try:
                input = json.loads(input)
            except json.JSONDecodeError:
                input = {"query_text": input, "context": {}}
        
        query_text = input.get("query_text", "")
        context = input.get("context", {})
        
        tool_decison_start_time = context.get("tool_decison_start_time",'')

        if tool_decison_start_time:
            decision_duration_ms = (time.time() - float(tool_decison_start_time)) * 1000
        else:
            decision_duration_ms = None

        result = asyncio.run(rescheduling_appointment.invoke(query_text, context))
        
        result['decision_duration_ms'] = decision_duration_ms

        result['current_tool']='appointment_rescheduling'

        return json.dumps(result)
    except Exception as e:
        logger.error(f"Error in run_register_patient: {str(e)}")
        return json.dumps({
            "output": f"Registration error: {str(e)}",
            "current_step": "",
            "collected_data": {},
            "status": "error"
        })
# LangChain tool decorator
rescheduling_appointment_tool = StructuredTool.from_function(
    func=run_rescheduling_appointment,
    name="Rescheduling Appointment",
    description=(
        "Rescheduling Appointment based on Appointment_id"
        "Input should be a dictionary with 'query_text' and 'context' or a JSON string."
    ),
    return_direct=True
)

__all__ = ["rescheduling_appointment_tool"]
