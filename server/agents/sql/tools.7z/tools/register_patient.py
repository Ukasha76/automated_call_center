from agents.sql.tools.functions.register_patient.extract_patient_info import extract_patient_info
from langchain.tools import StructuredTool
from typing import Dict, Any, Optional
from pydantic import BaseModel
from agents.sql.tools.functions.create_prompt import create_prompt
import random
import string
import logging
import asyncio
from agents.sql.tools.functions._build_response import _build_response

import re
import json
from pydantic import Field
from supabase import create_client, Client
from typing import Union  # Python 3.9+

supabase: Client = create_client(
    supabase_url="https://adxmtyjibwipeivrxcil.supabase.co",
    supabase_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFkeG10eWppYndpcGVpdnJ4Y2lsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzM3NDU1NDEsImV4cCI6MjA0OTMyMTU0MX0.0XPdpUTpBkWAuOvsdShIrSj6V6_EyQJnAuJW1eprMb4"
)



logger = logging.getLogger(__name__)

class PatientRegistrationTool:
    def __init__(self):
        self.current_step = "get_name"
        self.collected_data = {}

    async def invoke(self, input_data: Any, context: Dict = None) -> Dict:
        """Main entry point with complete type safety"""
        try:
            # Debug what we received
            logger.debug(f"Raw input: {input_data} (type: {type(input_data)})")

            # Convert to safe format
            safe_input = self._normalize_input(input_data)
            
            # Extract values with guarantees
            query = str(safe_input['query_text'])
            ctx = safe_input.get('context', {}) or (context if isinstance(context, dict) else {})
            
            logger.debug(f"Processing - query: '{query}', context keys: {list(ctx.keys())}")
            return await self.handle_query(query, ctx)
            
        except Exception as e:
            logger.error(f"Invoke error: {str(e)}", exc_info=True)
            return {
                "output": f"System error: {str(e)}",
                "status": "error",
                "debug": {
                    "input_received": str(input_data)[:100],
                    "input_type": str(type(input_data))
                }
            }

    def _normalize_input(self, input_data: Any) -> Dict[str, Any]:
        """Convert any input type to safe dictionary format"""
        # Handle primitive types
        if isinstance(input_data, (int, float)):
            return {"query_text": str(input_data), "context": {}}
        
        # Handle strings (could be JSON)
        if isinstance(input_data, str):
            try:
                data = json.loads(input_data)
                if isinstance(data, dict):
                    return data
                return {"query_text": str(data), "context": {}}
            except json.JSONDecodeError:
                return {"query_text": input_data, "context": {}}
        
        # Handle dictionaries
        if isinstance(input_data, dict):
            return {
                "query_text": str(input_data.get('query_text', input_data.get('input_data', ''))),
                "context": input_data.get('context', {})
            }
        
        # Fallback for any other type
        return {"query_text": str(input_data), "context": {}}
    
    async def handle_query(self, input_str: str, context: Dict[str, Any]) -> Dict:
        """
        Handles the patient registration process.
        Returns dict with:
        - response: string for user
        - current_step: next step identifier
        - collected_data: updated context
        - status: 'in_progress'|'complete'|'error'
        """
        self.current_step = context.get('registration_substep', 'get_name')
        self.collected_data = context.get('registration_data', {})
        self.collected_data['phone_number'] = context.get('collected_data', {}).get('phone_number')
        # self.collected_data['phone_number']=context.get('collected_data').get('phone_number')

        try:
            if self.current_step == 'get_name':
                return await (self._handle_name_step(input_str))
            elif self.current_step == 'get_gender':
                return await  (self._handle_gender_step(input_str))
            
            # elif self.current_step == 'get_phone':
            #     return await  (self._handle_phone_step(input_str))

            elif self.current_step == 'get_age':
                return await  (self._handle_age_step(input_str))
            elif self.current_step == 'get_address':
                return await  (self._handle_address_step(input_str))
            elif self.current_step == 'confirm':
                return await  (self._handle_confirmation_step(input_str))
            else:
                return self._reset_flow("Let's start your registration. What is your name?")
                
        except Exception as e:
            logger.error(f"Registration error: {str(e)}")
            return self._reset_flow("I encountered an error. Let's start over.")
    import re



    # async def _handle_name_step(self, input_str: str) -> Dict:
    #     """Comprehensive name handling with all validation built-in"""
    #     # Clean and prepare input
    #     input_str = str(input_str).strip() if input_str else ""
        
    #     # Case 1: Empty input at start of registration
    #     if not input_str and not self.collected_data.get('name'):
    #         return {
    #             'output': "Let's register a new patient. What is the patient's name?",
    #             'current_step': 'get_name',
    #             'collected_data': self.collected_data,
    #             'status': 'in_progress'
    #         }

    #     # // name_extracted = extract_patient_name(input_str)
    #     name_result = await extract_patient_info(input_str, 'name')

    #     # name_extracted = name_result["value"]
        
    #     if not name_result['success'] or name_result['value'] in ['""', "''"]:
    #         return {
    #             'output': "I didn't catch the name. Please provide just the patient's name.",
    #             'current_step': 'get_name',
    #             'collected_data': self.collected_data,
    #             'status': 'in_progress'
    #         }
    #     self.collected_data['name'] = name_result['value']
    #     print(type(self.collected_data))
    #     # Handle invalid name case
    #     return {
    #         'output': "What is the patient's gender? (Male/Female/Other)",
    #         'current_step': 'get_gender',
    #         'collected_data': self.collected_data,
    #         'status': 'in_progress'
    #     }
    # async def _handle_gender_step(self, input_str: str) -> Dict:
    #     """Handle gender input step"""
    #     try:
    #         result = await extract_patient_info(input_str, 'gender')
            
    #         if not result['success']:
    #             return {
    #                 'output': result['value'],
    #                 'current_step': 'get_gender',
    #                 'collected_data': self.collected_data,
    #                 'status': 'in_progress'
    #             }
    #         # # Convert to dict if it's a tuple
    #         # if isinstance(self.collected_data, tuple):
    #         #     self.collected_data = dict(self.collected_data)
                
    #         self.collected_data['gender'] = result.get('value', 'unknown')
    #         print(type(self.collected_data))  # This will confirm it's a tuple

    #         return {
    #             'output': "What is your phone number?",
    #             'current_step': 'get_phone',
    #             'collected_data': self.collected_data,
    #             'status': 'in_progress'
    #         }
    #     except Exception as e:
    #         logger.error(f"Error in gender step: {e}")
    #         return self._reset_flow("I encountered an error. Let's start over with your gender.")

    # async def _handle_phone_step(self, input_str: str) -> Dict:
    #     """Handle phone number input step"""
    #     try:
    #         result = await extract_patient_info(input_str, 'phone_number')
            
    #         if not result['success']:
    #             return {
    #                 'output': result['value'],
    #                 'current_step': 'get_phone',
    #                 'collected_data': self.collected_data,
    #                 'status': 'in_progress'
    #             }
            
    #         self.collected_data['phone_number'] = result['value']
    #         return {
    #             'output': "What is your age?",
    #             'current_step': 'get_age',
    #             'collected_data': self.collected_data,
    #             'status': 'in_progress'
    #         }
    #     except Exception as e:
    #         logger.error(f"Error in phone step: {e}")
    #         return self._reset_flow("I encountered an error. Let's start over with your phone number.")

    # async def _handle_age_step(self, input_str: str) -> Dict:
    #     """Handle age input step"""
    #     try:
    #         result = await extract_patient_info(input_str, 'age')
            
    #         if not result['success']:
    #             return {
    #                 'output': result['value'],
    #                 'current_step': 'get_age',
    #                 'collected_data': self.collected_data,
    #                 'status': 'in_progress'
    #             }
            
    #         self.collected_data['age'] = result['value']
    #         return {
    #             'output': "What is your address?",
    #             'current_step': 'get_address',
    #             'collected_data': self.collected_data,
    #             'status': 'in_progress'
    #         }
    #     except Exception as e:
    #         logger.error(f"Error in age step: {e}")
    #         return self._reset_flow("I encountered an error. Let's start over with your age.")

    # async def _handle_address_step(self, input_str: str) -> Dict:
    #     """Handle address input step"""
    #     try:

    #         result = await extract_patient_info(input_str, 'address')
            
    #         if not result['success']:
    #             return {
    #                 'output': result['value'],
    #                 'current_step': 'get_address',
    #                 'collected_data': self.collected_data,
    #                 'status': 'in_progress'
    #             }
            
    #         self.collected_data['address'] = result['value']
    #         return {
    #             'output': f"Please confirm your details:\n" +
    #                       f"Name: {self.collected_data['name']}\n" +
    #                       f"Gender: {self.collected_data['gender']}\n" +
    #                       f"Phone: {self.collected_data['phone_number']}\n" +
    #                       f"Age: {self.collected_data['age']}\n" +
    #                       f"Address: {self.collected_data['address']}\n\n" +
    #                       f"Is this correct? (yes/no)",
    #             'current_step': 'confirm',
    #             'collected_data': self.collected_data,
    #             'status': 'in_progress'
    #         }
    #     except Exception as e:
    #         logger.error(f"Error in address step: {e}")
    #         return self._reset_flow("I encountered an error. Let's start over with your address.")

    # async def _handle_confirmation_step(self, input_str: str) -> Dict:
    #     """Handle final confirmation and registration"""

    #     result = await extract_patient_info(input_str, 'confirmation')
    #     try:

    #         if result['success']:
    #             if result['value'] == "yes":
    #                 result = await create_patient_record(self.collected_data)
    #                 if not result['success']:
    #                     return {
    #                         'output': result['value'],
    #                         'current_step': 'get_name',
    #                         'collected_data': {},
    #                         'status': 'error'
    #                     }
    #                 return {
    #                     'output': result['value'],
    #                     'current_step': 'complete',
    #                     'collected_data': {},
    #                     'status': 'complete'
    #                 }
    #                 # return {
    #                 #     'output': f"Invoke the Booking tool to book the appointment {result['value']}.",
    #                 #     'current_step': 'assure_registration',
    #                 #     'collected_data':self.collected_data['phone_number'],
    #                 #     'status': 'in_progress'
    #                 # }

    #             elif result['value'] == "no":
    #                 return self._reset_flow("Let's start over. What is your name?")
    #         else:
    #             return {
    #                 'output': result['value'],
    #                 'current_step': 'confirm',
    #                 'collected_data': self.collected_data,
    #                 'status': 'in_progress'
    #             }

    #     except Exception as e:
    #         logger.error(f"Database error: {str(e)}")
    #         return {
    #             'output': "Sorry, I couldn't complete your registration. Please try again.",
    #             'current_step': 'get_name',
    #             'collected_data': {},
    #             'status': 'error'
    #         }
    async def _handle_name_step(self, input_str: str) -> Dict:
        """Comprehensive name handling with all validation built-in"""
        # Clean and prepare input
        input_str = str(input_str).strip() if input_str else ""
        
        # Case 1: Empty input at start of registration
        if not input_str and not self.collected_data.get('name'):
            return _build_response(
                "Let's register a new patient. What is the patient's name?",
                'get_name',
                self.collected_data,
                'in_progress',
                "patient_registration"
            )

        name_result = await extract_patient_info(input_str, 'name')
        
        if not name_result['success'] or name_result['value'] in ['""', "''"]:
            return _build_response(
                "I didn't catch the name. Please provide just the patient's name.",
                'get_name',
                self.collected_data,
                'in_progress',
                "patient_registration"
            )
        
        self.collected_data['name'] = name_result['value']
        
        return _build_response(
            "What is the patient's gender? (Male/Female/Other)",
            'get_gender',
            self.collected_data,
            'in_progress',
            "patient_registration"
        )

    async def _handle_gender_step(self, input_str: str) -> Dict:
        """Handle gender input step"""
        try:
            result = await extract_patient_info(input_str, 'gender')
            
            if not result['success']:
                return _build_response(
                    result['value'],
                    'get_gender',
                    self.collected_data,
                    'in_progress',
                    "patient_registration"
                )
                
            self.collected_data['gender'] = result.get('value', 'unknown')
            
            return _build_response(
                "What is your age?",
                'get_age',
                self.collected_data,
                'in_progress',
                "patient_registration"
            )
        except Exception as e:
            logger.error(f"Error in gender step: {e}")
            return self._reset_flow("I encountered an error. Let's start over with your gender.")

    async def _handle_phone_step(self, input_str: str) -> Dict:
        """Handle phone number input step"""
        try:
            result = await extract_patient_info(input_str, 'phone_number')
            
            if not result['success']:
                return _build_response(
                    result['value'],
                    'get_phone',
                    self.collected_data,
                    'in_progress',
                    "patient_registration"
                )
            
            self.collected_data['phone_number'] = result['value']
            
            return _build_response(
                "What is your age?",
                'get_age',
                self.collected_data,
                'in_progress',
                "patient_registration"
            )
        except Exception as e:
            logger.error(f"Error in phone step: {e}")
            return self._reset_flow("I encountered an error. Let's start over with your phone number.")

    async def _handle_age_step(self, input_str: str) -> Dict:
        """Handle age input step"""
        try:
            result = await extract_patient_info(input_str, 'age')
            
            if not result['success']:
                return _build_response(
                    result['value'],
                    'get_age',
                    self.collected_data,
                    'in_progress',
                    "patient_registration"
                )
            
            self.collected_data['age'] = result['value']
            
            return _build_response(
                "What is your address?",
                'get_address',
                self.collected_data,
                'in_progress',
                "patient_registration"
            )
        except Exception as e:
            logger.error(f"Error in age step: {e}")
            return self._reset_flow("I encountered an error. Let's start over with your age.")

    async def _handle_address_step(self, input_str: str) -> Dict:
        """Handle address input step"""
        try:
            result = await extract_patient_info(input_str, 'address')
            
            if not result['success']:
                return _build_response(
                    result['value'],
                    'get_address',
                    self.collected_data,
                    'in_progress',
                    "patient_registration"
                )
            
            self.collected_data['address'] = result['value']
            
            confirmation_message = (
                f"Please confirm your details:\n"
                f"Name: {self.collected_data['name']}\n"
                f"Gender: {self.collected_data['gender']}\n"
                f"Phone: {self.collected_data['phone_number']}\n"
                f"Age: {self.collected_data['age']}\n"
                f"Address: {self.collected_data['address']}\n\n"
                f"Is this correct? (yes/no)"
            )
            
            return _build_response(
                confirmation_message,
                'confirm',
                self.collected_data,
                'in_progress',
                "patient_registration"
            )
        except Exception as e:
            logger.error(f"Error in address step: {e}")
            return self._reset_flow("I encountered an error. Let's start over with your address.")

    async def _handle_confirmation_step(self, input_str: str) -> Dict:
        """Handle final confirmation and registration"""
        try:
            result = await extract_patient_info(input_str, 'confirmation')
            
            if result['success']:
                if result['value'] == "yes":
                    record_result = await create_patient_record(self.collected_data)
                    if not record_result['success']:
                        return _build_response(
                            record_result['value'],
                            'get_name',
                            {},
                            'error',
                            "patient_registration"
                        )
                    return _build_response(
                        record_result['value'],
                        None,
                        {},
                        'complete',
                        "patient_registration"
                    )
                elif result['value'] == "no":
                    return self._reset_flow("Let's start over. What is your name?")
            else:
                return _build_response(
                    result['value'],
                    'confirm',
                    self.collected_data,
                    'in_progress',
                    "patient_registration"
                )

        except Exception as e:
            logger.error(f"Database error: {str(e)}")
            return _build_response(
                "Sorry, I couldn't complete your registration. Please try again.",
                'get_name',
                {},
                'error',
                "patient_registration"
            )
    def _reset_flow(self, message: str) -> Dict:
        """Reset the registration flow"""
        self.current_step = 'get_name'
        self.collected_data = {}
        return {
            message,
            'get_name',
            {},
            # 'status': 'in_progress'
        }

async def create_patient_record(data: Dict) -> Dict:
    """
    Create a new patient record in the database
    """
    try:
        # Generate patient ID
        
        ALLOWED_FIELDS = {'name', 'gender', 'phone_number', 'age', 'address'}
        
        # Generate patient ID
        patient_id = ''.join(random.choices(string.digits, k=8))
        
        # Filter and validate required fields
        filtered_data = {
            field: str(data[field]) 
            for field in ALLOWED_FIELDS 
            if field in data
        }
        
        # Validate all required fields exist
        missing = ALLOWED_FIELDS - set(filtered_data.keys())
        if missing:
            return {
                'success': False,
                'value': f"Missing required fields: {', '.join(missing)}"
            }
        
        # Prepare final record
        patient_record = {
            "patient_id": patient_id,
            **filtered_data
        }
        
        # Insert into database
        result = supabase.table("patients").insert(patient_record).execute()
        
        if not result:
            raise Exception("Failed to save patient data")
        
        return {
            'success': True,
            'value': patient_id,
            'confidence': 1.0
        }
        
    except Exception as e:
        logger.error(f"Database error: {str(e)}")
        return {
            'success': False,
            'value': f"Failed to create patient record: {str(e)}",
            'confidence': 0.0
        }



# Input schema for registration

# Create tool instance
# registration_tool = PatientRegistrationTool()

class PatientRegistrationInput(BaseModel):
    input: Union[str, Dict[str, Any]] = Field(
        ...,
        description="Either a JSON string or dictionary containing 'query_text' and 'context'"
    )



import asyncio
from typing import Dict, Any, Union
import json
import logging
from functools import wraps

async def run_register_patient(query_text: str, context: Dict[str, Any]) -> str:
    """Async version of the registration function"""
    try:
        # Validate input
        if not isinstance(query_text, str) or not query_text.strip():
            raise ValueError("query_text must be a non-empty string")
        if not isinstance(context, dict):
            raise ValueError("context must be a dictionary")

        tool = PatientRegistrationTool()
        result = await tool.invoke({"query_text": query_text, "context": context})
        
        return result

    except Exception as e:
        error_msg = f"Registration failed: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return json.dumps({
            "output": error_msg,
            "current_step": "get_name",
            "collected_data": {},
            "status": "error"
        })

__all__ = ["run_register_patient"]