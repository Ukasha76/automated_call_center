# This file makes the appointmentSlots_info directory a Python package

from .get_available_slots import get_available_slots

__all__ = ['get_available_slots']
